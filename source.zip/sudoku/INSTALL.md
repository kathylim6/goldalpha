Welcome to Sudoku!

Installation of our program is very simple. You should not need to install any OPAM packages. Simply run
$ cd sudoku (if you are viewing from the goldalpaha folder, which is the main directory of our GitHub repo)
$ dune build
$ dune exec bin/main.exe

and begin playing our game!