This is our CS 3110 Final Group Project for the Fall 2025 Semesters. 
Our group members for team 97, Gold Alpha are:
* Yongjin Lee (yl2289)
* Katherine Lim (kl2229)
* Aditya Nandyal (an625)
* Tim Park (tkp26)

The only other external resource we used in this project was referencing Peter Norvig's famous 2006 essay on solving Sudoku puzzles (can be found here: https://norvig.com/sudoku.html) as inspiration for the development for our unique board generation algorithm. All code in this codebase was developed on our own. 